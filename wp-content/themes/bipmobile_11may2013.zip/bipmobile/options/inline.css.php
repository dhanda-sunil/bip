<?php
//header('Content-type: text/css');

$options = & BipMobileThemeOptions::getOptions();
$shortname = & BipMobileThemeOptions::cfg('shortname');
/*$layout = BipMobileThemeOptions::getLayoutCSS();
$sidebars = & BipMobileThemeOptions::getValueSets('SIDEBARS');
if (isset($sidebars ['values'][$layout])) include (TEMPLATEPATH . '/layouts/'.  $layout.'.css');*/

function getInherited($option_name, $sub_option_key){
	static $shortname = '';
	if (! $shortname) $shortname = BipMobileThemeOptions::cfg('shortname');
	$inherided = BipMobileThemeOptions::getInheritedOption($shortname . $option_name,$sub_option_key);
	return $inherided['value'];
}
function echoInherited($option_name, $sub_option_key){
	static $shortname = '';
	if (! $shortname) $shortname = BipMobileThemeOptions::cfg('shortname');
	$inherided = BipMobileThemeOptions::getInherited($shortname . $option_name,$sub_option_key);
	echo $inherided;
}
?>


/* DEFAULT STYLES */
body { letter-spacing: 0px; background:<?php echo $options[$shortname . '_header_bg_color_background'];?>; color:#fff; font-size:14px;}

*{margin:0;padding:0;}

.clear{clear:both;}

p { margin: 15px 0; }

h1, .widget-title{	font-style: italic;}

h1, h2, h3, .widget-title > * {
	font-family: Akronim, Helvetica, 'Novecentowide-Bold', 'Ariab Black', Arial, sans-serif;
	font-size: 24px;
	line-height: 30px;
	letter-spacing: -1px;
	text-transform: uppercase;
}

.page-title > *, .widget-title > * {
	color: #000;
}
.page-title a:hover { color: #fff; text-decoration: none; }
h2, h3 { font-size: 20px; line-height: 24px; }
ul li {list-style:none;}

.txt-right{text-align:right;}
.txt-center{text-align:center;}

.slim{font-weight:normal;}
.larger{margin:10px 0;font-size:64px; line-height:48px;}

a {outline: none !important; text-decoration:none; }
a:hover{
	text-decoration:none; 
}

.portfolio-items a dt img, nav a, .social-profiles a img, .connect a img, #copyright a img   {
	-webkit-transition: all 0.15s linear;
	-moz-transition: all 0.15s linear;
	-o-transition: all 0.15s linear;
	transition: all 0.15s linear;
}
hr{
	border-top:1px solid rgba(209,209,209,0.2);
	border-bottom:0px solid rgba(209,209,209,0.2);
	box-shadow: 0px 0px 5px 0.3px rgba(209,209,209,0.5);
	margin:5px 0px 0px;
}
hr.dotted{
	border-top:1px dotted #747474;
	border-bottom:0px solid rgba(209,209,209,0.2);
}
.row {
	margin:0px;
}
/*[class*="span"]:first-child{
	margin-left:0px;
}*/
select, textarea, input[type="text"], input[type="password"], input[type="datetime"], input[type="datetime-local"], input[type="date"], input[type="month"], input[type="time"], input[type="week"], input[type="number"], input[type="email"], input[type="url"], input[type="search"], input[type="tel"], input[type="color"], .uneditable-input{
	height:auto;line-height:20px;
}

/* HEADER */
#header {
	position: relative;
	top: 0;
	left: 0;
	z-index: 0;
	width: 100%;
	min-height:150px;
}
#header #logo {
	position:absolute;
	top:20px;
}
#logo img { display: block;}

#header .menu{position:absolute;top:10px;<?php echo $options[$shortname . '_homepage_all_menu_position'];?>:<?php echo $options[$shortname . '_homepage_all_menu_margin'];?>;z-index:1;}
#header nav ul { margin:8px 0 0 0; padding: 0 0 0 5px;}
#header nav ul li {list-style-type: none; line-height:15px; text-align:<?php echo $options[$shortname . '_homepage_all_menu_position'] ?>;}
#header nav a {
	color: #fff;
	font-size: 15px;
	font-weight: normal;
	letter-spacing: 0px;
	padding:3px 8px;
}

#footer .footer-menu{float:<?php echo $options[$shortname . '_footer_postion'];?>;}
#footer nav ul { margin:8px 0 0 0; padding: 0 0 0 5px;}
#footer nav ul li {display:inline-block; list-style-type: none; line-height:15px; text-align:center;}
#footer nav a {
	color: #fff;
	font-size: 15px;
	font-weight: normal;
	letter-spacing: 0px;
	padding:3px 8px;
}
#header .search{
	border:1px solid #D1CFD2;
}
#header .search input[type="text"]{
	float:left;
	font-size: 15px;
	background:#fff;
	/*width:100px;*/
	line-height:20px;
	height:22px;
	padding:2px;
	margin:2px;
	text-indent:5px;
}
#header .search input[type="submit"]{
	float:left;
	background:#fff url(assets/img/search.png) no-repeat;
	line-height:25px;
	height:25px;
	/*width:25px;*/
	margin:2px;
	padding:0px;
	text-indent:5px;
}
.select-menu { display: none; }

.flexslider { overflow: hidden; max-height:480px }
.flexslider .controls{
	width:160px;
	height:100%;
	position:absolute;
	top:0;	
	z-index:1;
	font-size:48px;
	color:#fff;
}
.flexslider .controls span{
	position:absolute;
	top:45%;
}
.flexslider.regular .controls{
	background: <?php echo $options[$shortname . '_header_bg_color_background'];?>;
    opecity:0.9;
}
.flexslider .controls.left{
	left:0;
	float:left;
	text-align:right;
	padding-right:20px;
}
.flexslider .controls.left span{
	right:20px;
}
.flexslider .controls.right{
	right:0;
	float:right;
	text-align:left;
	padding-left:20px;
}
.flexslider .site-title{
	padding: 0;
	background: none;
	position: absolute;
	top: 20px;
	left: 0;
	right: 0;
	color: #fff;
	font-size: 20px;
	line-height: 25px;
	margin: 0 100px;
	text-align: center;
}
.flexslider .slider-content {
	padding: 0;
	background: none;
	position: absolute;
	top: 100px;
	color: #fff;
	left: 50%;
}
.flexslider .slider-content h1{
	font-size: 60px;
	line-height: 65px;
}
.flexslider.full_screen .slider-content{
	right: 0;
	text-align: left;
	margin: 0 100px 0 0;
}
.flex-direction-nav a{
	width:45%;
	top:45%;
	height:50px;
}
.header-bottom{
	background:#fff;
	min-height:80px;
	border-bottom:5px dotted #ccc;
}


/* CONTENT */
body{ background:<?php echo $options[$shortname . '_header_bg_color_background'];?>; background-image:<?php echo ($options[$shortname . '_backgroud_page_layout']=='regular')?'url("wp-content/themes/untouchable/assests/img/custome__photo.png")':'';?>;}/*get_template_directory_uri*/

.page { text-align: left; }
.page.type-post, .home.page { background:#fff; color:#000; }
.page.type-post a{color:#000;}
.page-title, #footer .widget-title {
	text-align: left;
	padding-bottom: 17px;
}
.page-title h1 { min-width: 190px; }
.page-title h1, #footer .widget-title > * { margin: 0; }
.postDesc{
	font-size:80%;font-weight:normal;
}
.postContent{
	text-align:justify;
}
.post-title{
	position:absolute;
	left:50%;
	padding:0px 10px;
	margin-top:-140px;
	background:#000;
	text-align:center;
	color:#fff;
	border-radius:5px 5px 0 0;
}
.post-content{
	padding:5px 20px 20px;
	background:#fff;
	text-align:justify;
	color:#000;
	position: relative;
	margin-top: -112PX;
}
.recent-posts{
	margin:50px 0px;
}
.pull-right { float: right; }
.pull-left { float: left; }

.product-item img {
	margin: 5px;
	background: #fff;
}

/* MODAL STYLES FROM BOOTSTRAP */
.modal-backdrop {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1040;
  background-color: #000000;
}
.modal-backdrop.fade {
  opacity: 0;
}
.modal-backdrop,
.modal-backdrop.fade.in {
  opacity: 0.8;
  filter: alpha(opacity=80);
}
.modal {
  position: absolute;
  top: auto !important;
  left: 50%;
  z-index: 1050;
  max-width: 940px;
  margin:  0 0 0 -470px;
  overflow: hidden;
  background-color: #ffffff;
  border: 1px solid #999;
  border: 1px solid rgba(0, 0, 0, 0.3);
  -webkit-border-radius: 6px;
  -moz-border-radius: 6px;
  border-radius: 6px;
  -webkit-box-shadow: 0 3px 7px rgba(0, 0, 0, 0.3);
  -moz-box-shadow: 0 3px 7px rgba(0, 0, 0, 0.3);
  box-shadow: 0 3px 7px rgba(0, 0, 0, 0.3);
  -webkit-background-clip: padding-box;
  -moz-background-clip: padding-box;
  background-clip: padding-box;
  outline: none;
}
.modal.fade {
  -webkit-transition: opacity .3s linear, top .3s ease-out;
  -moz-transition: opacity .3s linear, top .3s ease-out;
  -o-transition: opacity .3s linear, top .3s ease-out;
  transition: opacity .3s linear, top .3s ease-out;
  top: -25%;
}
.modal.fade.in { top: 50%; }
.modal-header { padding: 9px 15px; border-bottom: 1px solid #eee; }
.modal-header .close { margin-top: 2px; }
.modal-header h3 { margin: 0; line-height: 30px; }
.modal-body { overflow-y: auto; }
.modal-form { margin-bottom: 0; }
.modal-footer {
  padding: 14px 15px 15px;
  margin-bottom: 0;
  text-align: right;
  background-color: #f5f5f5;
  border-top: 1px solid #ddd;
  -webkit-border-radius: 0 0 6px 6px;
  -moz-border-radius: 0 0 6px 6px;
  border-radius: 0 0 6px 6px;
  -webkit-box-shadow: inset 0 1px 0 #ffffff;
  -moz-box-shadow: inset 0 1px 0 #ffffff;
  box-shadow: inset 0 1px 0 #ffffff;
  *zoom: 1;
}
.modal-footer:before,
.modal-footer:after {
  display: table;
  content: "";
  line-height: 0;
}
.modal-footer:after {
  clear: both;
}
.modal-footer .btn + .btn {
  margin-left: 5px;
  margin-bottom: 0;
}
.modal-footer .btn-group .btn + .btn {
  margin-left: -1px;
}
.modal-footer .btn-block + .btn-block {
  margin-left: 0;
}
/* MODAL STYLES FROM BOOTSTRAP */


.modal { display: none; text-align: left; background: #fff; }
.modal-header { height: 70px; background: #ebe9e4; overflow: hidden; }
.modal-header .close {
	width: 34px;
	height: 34px;
	background: url("assets/img/close.png");
	text-indent: -999px;
	overflow: hidden;
	margin: 17px 22px 0 0;
	opacity: 0.5;
}
.modal-header .close:hover { opacity: 1; }
.modal-body {
	font-size: 18px;
	line-height: 25px;
	overflow: hidden;
	margin: 15px 20px;
}
.modal-body h1 { margin-top: 25px; }
.modal-body .meta { float: right; color: #8f8f8f; margin-top: 0; width: 25%; }
.modal-body .meta li { list-style-type: none; border-top: #e9e9e9 1px dashed; padding: 5px 0; }
.modal-body .meta li:first-child { border: none; padding-top: 0; }



/* WIDGETS */
.home-widgets{margin:20px 0px;}
article .widget-area { border-top: #e9e9e9 1px dashed; margin-top: 67px; }

article .widget-area .widget:first-child { border-left: #e9e9e9 1px dashed; }
article .widget-area .widget { border-right: #e9e9e9 1px dashed; }

.widget { font-size: 18px; line-height: 25px; }

.widget-teaser { padding-top: 32px; }
.widget-teaser .widget-title { margin: 30px 0 54px; }
.widget-teaser img { margin: 0 auto; display: block; }
.widget-teaser .widget-content { padding: 52px 15px; border-top: #e9e9e9 1px dashed; }

#footer .widget { margin-bottom: 40px; }
#footer .widget-title { background-image: url("assets/img/title-arrow-2.png"); padding-bottom: 10px; }
#footer .widget-title > * {
	background: #24282f;
	width: 100%;
	padding-left: 0;
	padding-right: 0;
}

#footer .untouchable-flickr-photostream-widget .widget-content { padding: 0; overflow: hidden; }
.untouchable-flickr-photostream-widget .widget-content > div { width: 110%; overflow: hidden; }
.flickr_badge_image img {
	display: block;
	width: 80px;
	height: 80px;
	float: left;
	margin: 30px 30px 0 0;
}
.width-33 { width: 33.1%; float: left; }

/* PORTFOLIOS & TEAMS & PRODUCTS */
.portfolio-items, .staff-items, .product-items { margin: 0px 0px 50px; }
.portfolio-items a{ color: #000; }
.portfolio-items dl, .staff-items dl, .product-items dl{
	margin-top: 0;
	margin-bottom: 40px;
}
.portfolio-items dl{
	box-shadow: -2px 4px 10px 6px rgba(0,0,0,0.3);
}
.portfolio-items dt, .staff-items dt, .product-items dt{
	padding:10px;
	background: #fff;
	text-align:center;
}
.portfolio-items dt img, .staff-items dt img, .product-items dt img {
	 width: auto;
	 opacity: 1;
	 max-height: 150px;
	 min-height: 150px;
}
.portfolio-items dd, .staff-items dd, .product-items dd{
	margin: 0px;
	text-align: center;
	font-size: 12px;
	padding: 16px 0 0px;
}
.portfolio-items dd{
	background: #fff;	
}

.portfolio-items a:hover dt img { opacity: 0.7; }
.staff-items dd { padding: 18px 0 16px; font-size: 17px; color: #ccc9ba; }
.staff-items dd h3 { margin: 0; color: #666; }
.staff-items p { margin-top: 4px; margin-bottom: 19px; }

.social-profiles {
	overflow: hidden;
	text-align: center;
	padding: 13px 0 0;
	margin-bottom: 0;
	border-top: #e0e0e0 1px dashed;
}
.social-profiles li { list-style-type: none; display: inline-block; margin: 0 6px; }
.social-profiles a:hover img { opacity: 0.7; }

.connect { overflow: hidden; margin: 82px 0 75px; padding: 0; }
.connect a:hover img { opacity: 0.7; }
.connect li { list-style-type: none; float: left; width: 82px; margin: 0 44px; }
.connect li:first-child { margin-left: 0; }
.connect li:last-child { margin-right: 0; }

/* CALENDAR */
#calendar{
	margin-bottom:50px;
}
/* CONTACT */
.untouchable-google-map {
	margin: 54px 0 44px;
	display: block;
	width: 100%;
	height: 490px;
	max-width: 100%;
	border: none;
}
.untouchable-google-map img { max-width: none; }

.address { text-align: left; font-size: 18px; line-height: 25px; }
.address p { margin: 25px 0; }
.address form { margin: 30px 0 70px; }

/*input[type="submit"] {
	font-family: 'Novecentowide-Bold', 'Ariab Black', Arial, Helvetica, sans-serif;
	font-size: 25px;
	background: #94c01c;
	color: #fff;
	border: none;
	padding: 8px 38px 12px 36px;
}
input[type="text"], textarea {
	background: #f3f3ef;
	font-size: 20px;
	display: block;
	width: 100%;
	border: none;
	box-shadow: none;
	height: 60px;
	line-height: 58px;
	padding: 0;
	text-indent: 18px;
	margin: 0 0 18px;
}*/
textarea {
	line-height: 24px;
	padding: 18px;
	width: 100%;
	text-indent: 0;
}
.textarea-container { margin: 0 18px; }
.textarea-container textarea { margin-left: -18px; }
#contact textarea { width: 344px; height: 100px; }
.social{
	text-align:center;
}
.social .icon{
	width:100%;
	height:30px;
}
.social .icon.instagram{
	background: url(assets/img/astagram.png) center center no-repeat;
}
.social .icon.facebook{
	background: url(assets/img/facebook.png) center center no-repeat;
}
.social .icon.twitter{
	background: url(assets/img/twitter.png) center center no-repeat;
}
.social .icon.rss{
	background: url(assets/img/rss.png) center center no-repeat;
}
.social .icon.tumblr{
	background: url(assets/img/tumblr.png) center center no-repeat;
}
.social .icon.google{
	background: url(assets/img/google.png) center center no-repeat;
}

/* FOOTER */
#footer { background: <?php echo $options[$shortname . '_footer_bg_color_background'];?>; color: #fff;}
#footer .container {padding:15px 0 ;}
#footer #flogo{float:<?php echo $options[$shortname . '_footer_postion'];?>}
#footer #flogo img{height:75px;}
#footer p { margin: 25px 0; }
#copyright {
	background: #24282f;
	padding: 20px 0 0;
	height: 80px;
	color: #d5d5d5;
	font-weight: bold;
	font-size: 15px;
	line-height: 62px;
}
#copyright img { display: block; }
#copyright a:hover img { opacity: 0.7; }



@media (min-width: 768px) and (max-width: 979px) {

	#header nav li { margin-left: 20px; }

	.slider h1 { font-size: 42px; line-height: 48px; top: 34px; }
	.flex-control-nav { bottom: 36px; }

	.modal { max-width: 748px; margin:  0 0 0 -374px; }

	.connect li { margin: 0 22px; }

	#contact textarea { width: 254px; }
}

@media (max-width: 767px) {

	body { padding: 163px 0 0; }

	.container { margin: 0 20px; }

	#logo img { float: none; margin: 0 auto 24px; }
	.select-menu {
		display: block;
		margin-top: 12px;
		width: 100%;
		padding: 1px 0 0;
	}

	.slider h1 {
		font-size: 26px;
		line-height: 30px;
		top: 36px;
		margin: 0;
	}
	.flex-control-nav { bottom: 20px; }

	article .widget-area { margin: 40px 0 30px; }
	.widget-teaser .widget-title { margin-top: 16px; }
	article .widget, .widget-teaser .widget-content, article .widget-area { border: none !important; }

	.width-33 { width: 100%; }

	.widget-teaser .widget-title { margin-bottom: 20px; }
	.widget-teaser .widget-content { border-bottom: #e9e9e9 1px dashed; border-top: none; padding-top: 0; }

	#contact textarea { max-width: 100%; }

	.modal { max-width: 100%; left: 0; right: 0; margin-left: auto; }
	.modal-body .meta { float: none; width: auto; padding: 0; }

	.connect { text-align: center; }
	.connect li, .connect li:first-child, .connect li:last-child { margin: 10px; display: inline-block; float: none; }

	#header nav { display: none; }

}

@media (max-width: 480px) {
	.slider h1 { font-size: 16px; line-height: 20px; top: 16px; }
	.flex-control-nav { bottom: 10px; }
}

.alignleft { float: left; }
.alignright { float: right; }
.aligncenter {
	display: block;
	margin-left: auto;
	margin-right: auto;
}

.wp-caption {
	max-width: 100%; /* Keep wide captions from overflowing their container. */
	padding: 4px;
}
.wp-caption .wp-caption-text,
.gallery-caption,
.entry-caption {
	font-style: italic;
	font-size: 12px;
	font-size: 0.857142857rem;
	line-height: 2;
	color: #757575;
}
.gallery-caption { width: 90%; }
.gallery-caption a { display: inline; }